From swear nouns, I (Kalina) deleted for now: 
 - hell -> mostly used as what the hell and similar, not directed at the politician
 - gay -> mostly gay marriage, gay rights
 - shite -> we need a way to identify the mentions only directed at the politician, as more often than not, that's not the case
 - fuck -> again, we need to identify when directed. For now, replaced with fuck off, fuck wit, fuck you and all other variations that are more directed at a person
 - arse, ass -> made more concrete "your arse" coz most occurrences were "my arse" and other not-directed at the politician
 - same for butt & bum
 - damn -> deleted as it wasn't directed at the politicians 
 - idiot -> you idiot, as it wasn't directed at the politicians a lot of the time
 - ho - deleted, as mostly truncated words or hi/hey ho
 - bullshit -> deleted, as most often not directed at the politician and also more slang these days
 - bastard -> more of an insult really, so added there
 - bollocks - for now, left in in the swear words, but I'm not sure we want it in
 - lesbian -> it was mostly referring to lesbian and gay rights and predominently not directed at the politician
 - shit -> mostly used in the sense of X gives a shit, stop talking shit, etc. so removed
 - removed nancy (homophobic term) - most mentions were of politicians called Nancy
 - crap - deleted

Tom and I agreed to have a separate list of strong words (or offensive words), to use for the general tagging of offensive language. These are complementary to the swear nouns and insults, which are much stronger. There should be no overlap between them. 

The strength of words was derived from this OfCom & Ipsus Mori report: 
https://www.ofcom.org.uk/__data/assets/pdf_file/0022/91624/OfcomOffensiveLanguage.pdf 

Nicely summarised in https://www.indy100.com/article/british-swear-words-ranked-ofcom-7340446


Below is how the words we used differ from the original gazetteer used in https://gate.ac.uk/applications/sentiment.html:

=======================
 REMOVED
=======================
anal   
arse   
arsing   
ass   
axwound   
blasted   
bloody   
blooming   
blow job  
blowjob   
bollock   
bollocks   
bollok   
bollox   
bugger   
bullshit   
bum   
butt   
buttplug   
clitoris   
cock   
cock-up   
cocksucking   
cockup   
crap   
crappy   
cunnilingus   
damn   
dicksucking   
dodgy   
dozy   
feck   
felching   
fellate   
fellatio   
fishbum   
fishbums   
flange   
fuck   
fucked   
fucked up  
fuckin   
fucking   
fucks   
fudge packer  
garbage   
gay   
get lost  
God damn  
Goddamn   
goddamn   
goddamnit   
gormless   
grotty   
guido   
hell   
ho   
hoe   
humping   
knob end  
knobend   
labia   
lesbian   
lmao   
lmfao   
manky   
minge   
minging   
mingy   
mothafuckin   
mothafucking   
motherfucking   
munging   
naff   
nancy   
omg   
piss   
pissed   
pissed off  
po-faced   
poop   
poxy   
pube   
pussylicking   
s hit  
screwed   
scrotum   
sex   
sh1t   
shit   
shitcanned   
shite   
shittiest   
shitting   
shitty   
shiz   
shiznit   
skanky   
smegma   
snatch   
spunk   
utter bollocks  
vagina   
wtf

=======================
 ADDED
=======================
a cock  
arse bandit  
arsebandit   
axewound   
batty boy  
bellend   
bum boy  
bum clat  
chinky   
clunge   
cow   
coward   
cretin   
cripple   
darky   
die   
dork   
dumb fuck  
execute   
executed   
fanny   
FU   
fuck off  
fuck you  
fuckyou   
GFY   
gippo   
golliwog   
hang   
honky   
hung   
jo cox  
kill   
lezza   
loony   
minger   
mong   
moron   
moron   
murder   
murdered   
negro   
nig-nag   
nonce   
oaf   
polack   
poof   
poofter   
prickteaser   
psycho   
punani   
rag head  
raghead   
rape   
raped   
retard   
rugmuncher   
schizo   
scum   
scumbag   
slag   
slapper   
sociopath   
son of a bitch
stab   
stabbed   
STFU   
tart   
tranny   
u cock  
wanker   
wazzock   
wimp   
witch   
wog   
you cock  
you idiot  
your arse  
your ass  
