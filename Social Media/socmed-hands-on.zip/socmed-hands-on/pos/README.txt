To train a model:

1. Create a .props file describing the source data and model algorithm

2. Give .props file a reference ID (e.g. twitter_irc-ptb.1.props)

3. Run this:
  java -classpath stanford-postagger.jar edu.stanford.nlp.tagger.maxent.MaxentTagger -prop PROPS_FILE_FROM_STEP_2

4. add props and model to svn



To evaluate a model:

1. java -classpath stanford-postagger.jar edu.stanford.nlp.tagger.maxent.MaxentTagger -testFile corpora/stanford-twitter-dev.txt -model models/MODEL_FILENAME

2. record in results.ods incl. props file reference

