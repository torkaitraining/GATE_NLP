# NN_Framework
GATE neural network machine learning framework.

## Requirement:
* Anaconda

## Install
* (Windows) conda env create -f env_win.yml
* (Linux) conda env create -f env_lin.yml
