rm report.xml
gcp-direct.sh -x pythonpr-count-words.xgapp -t 2 -i data/docs
