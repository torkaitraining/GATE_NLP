#!/bin/bash
jupyter nbconvert module11-python.ipynb --execute --to slides 
