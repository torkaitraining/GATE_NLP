package module8.part1;

import gate.*;
// other imports go here


public class Main {
  public static void main(String... args) throws Exception {
    System.out.println("Hello world");
    // your code goes here
  }
}
