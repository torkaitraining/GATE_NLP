docName = doc.getName();

for (person in inputAS.get("Person")) {
    person.getFeatures().put("docName", docName);
}
