// set the annotation type from an annotation in the document
intStart = inputAS["Interesting"].start()
intEnd = inputAS["Interesting"].end()

// add the new annotations
outputAS.add(doc.start(), doc.end(), "WholeDoc", Factory.newFeatureMap())
outputAS.add(doc.start(), intStart, "BeforeInt", Factory.newFeatureMap())
outputAS.add(intStart, doc.end(), "IntZone", Factory.newFeatureMap())
outputAS.add(intEnd, doc.end(), "AfterInt", Factory.newFeatureMap())


