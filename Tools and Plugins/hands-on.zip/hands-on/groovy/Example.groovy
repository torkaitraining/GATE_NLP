// Print the name of the current document
println doc.getName()

// Print the text underlying each Person annotation
inputAS["Person"].each{ anno ->
  println "  " + doc.stringFor(anno)
}

// Record the number of Person annotations
doc.getFeatures().put("nbr_persons", inputAS["Person"].size())

// Flag whether the document contains any Person annotations;
// this feature can be used in a Conditional Corpus Pipeline.
doc.getFeatures().put("has_persons", ! inputAS["Person"].isEmpty())